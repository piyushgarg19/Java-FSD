package conversionstring;

public class ConversionString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		   String str = "Hii, Nice!";

	        // Convert String to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(str);
	        stringBuffer.append(" Goodbye!");
	        System.out.println("StringBuffer: " + stringBuffer);

	        // Convert String to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(str);
	        stringBuilder.append(" Have a nice day!");
	        System.out.println("StringBuilder: " + stringBuilder);

	}

}
