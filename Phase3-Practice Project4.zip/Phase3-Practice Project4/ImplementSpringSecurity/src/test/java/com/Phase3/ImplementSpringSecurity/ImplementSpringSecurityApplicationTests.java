package com.Phase3.ImplementSpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImplementSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
