package com.template;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestTemplateInputProjecApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestTemplateInputProjecApplication.class, args);
	}

}
