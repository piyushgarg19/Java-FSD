package com.ecommerce.controllers;

import org.springframework.stereotype.Repository;

@Repository
public class ProductRepository {

}
