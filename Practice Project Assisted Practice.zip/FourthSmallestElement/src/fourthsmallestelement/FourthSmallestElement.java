package fourthsmallestelement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FourthSmallestElement {
	
	public static int findFourthSmallest(List<Integer> list) {
        if (list.size() < 4)
        {
            throw new IllegalArgumentException("List size is less than 4.");
        }

        // Sort the list in ascending order
        
        Collections.sort(list);

        // Return the fourth smallest element
        
        return list.get(3);
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	        List<Integer> list = new ArrayList<>();
	        list.add(10);
	        list.add(2);
	        list.add(5);
	        list.add(1);
	        list.add(7);
	        list.add(3);

	        int fourthSmallest = findFourthSmallest(list);
	        System.out.println("Fourth smallest element: " + fourthSmallest);

	}

}
