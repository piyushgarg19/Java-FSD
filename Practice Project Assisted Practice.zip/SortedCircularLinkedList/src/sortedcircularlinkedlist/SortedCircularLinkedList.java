package sortedcircularlinkedlist;

public class SortedCircularLinkedList {
	
	static class Node {
        int data;
        Node next;
      
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
  
    static Node insert(Node head, int data) {
        Node newNode = new Node(data);
      
        if (head == null)
        {
            newNode.next = newNode;
            return newNode;
        }
      
        Node current = head;
      
        if (data <= current.data) 
        {
            while (current.next != head) 
            {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            return newNode;
        }
      
        while (current.next != head && current.next.data < data)
        {
            current = current.next;
        }
      
        newNode.next = current.next;
        current.next = newNode;
        return head;
    }
  
    static void printList(Node head) 
    {
        if (head == null)
        {
            return;
        }
      
        Node current = head;
      
        do{
            System.out.print(current.data + " ");
            current = current.next;
        } 
        while (current != head);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  Node head = null;
	    
	        head = insert(head, 1);
	        head = insert(head, 5);
	        head = insert(head, 9);
	        head = insert(head, 7);
	        head = insert(head, 3);
	      
	        System.out.println("Sorted Circular Linked List:");
	        printList(head);

	}

}
