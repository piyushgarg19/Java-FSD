/**
 * 
 */
/**
 * 
 */
module RotationArray {
}