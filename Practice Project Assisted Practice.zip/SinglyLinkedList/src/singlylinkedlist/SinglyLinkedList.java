package singlylinkedlist;

class Node {
    int data;
    Node next;

    Node(int data)
    {
        this.data = data;
        this.next = null;
    }
}

class LinkedList 
{
    Node head;

    LinkedList() 
    {
        this.head = null;
    }

    void insert(int data) 
    {
        Node newNode = new Node(data);

        if (head == null) 
        {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null)
            {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    void delete(int key) 
    {
        if (head == null) 
        {
            System.out.println("List is empty.");
            return;
        }

        if (head.data == key) 
        {
            head = head.next;
            return;
        }

        Node current = head;
        Node prev = null;

        while (current != null && current.data != key)
        {
            prev = current;
            current = current.next;
        }

        if (current == null) 
        {
            System.out.println("Key not found in the list.");
            return;
        }

        prev.next = current.next;
    }

    void display() 
    {
        Node current = head;
        while (current != null) 
        {
            System.out.print(current.data + " ");
            current = current.next;
        }
        
        System.out.println();
    }
}
public class SinglyLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList linkedList = new LinkedList();

        linkedList.insert(10);
        linkedList.insert(20);
        linkedList.insert(30);
        linkedList.insert(40);
        linkedList.insert(50);

        System.out.println("Original Linked List:");
        linkedList.display();

        int key = 50;
        linkedList.delete(key);

        System.out.println("Linked List after deleting the first occurrence of " + key + ":");
        linkedList.display();
		

	}

}
