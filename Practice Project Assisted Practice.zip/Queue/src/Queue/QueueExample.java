package Queue;

import java.util.*;

public class QueueExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<String> locationsQueue = new LinkedList<>();
		
		locationsQueue.add("Allahabad");
		locationsQueue.add("Varanshi");
		locationsQueue.add("Ujjain");
		locationsQueue.add("Mathura Vrindavan");
		locationsQueue.add("Jagannathpuri");
		locationsQueue.add("Gujrat");
		locationsQueue.add("Mumbai");
		locationsQueue.add("Delhi");
		locationsQueue.add("Kolkata");
		locationsQueue.add("Deoband");
		
		System.out.println("Queue is : " + locationsQueue);
		System.out.println("Head of Queue : " + locationsQueue.peek());
		
		locationsQueue.remove();
		
		System.out.println("After removing Head of Queue : " + locationsQueue);
		System.out.println("Size of Queue : " + locationsQueue.size());
		
	}
	
}

		
		        		
		 