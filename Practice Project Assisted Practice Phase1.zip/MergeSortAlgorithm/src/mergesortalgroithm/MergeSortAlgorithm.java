package mergesortalgroithm;

public class MergeSortAlgorithm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] array1 = {21,23,25,27,29};
	     int[] array2 = {22,24,26,28,30};
	        
	        int[] mergedArray = mergeArrays(array1, array2);
	        
	        System.out.println("Merged Array:");
	        
	        for (int num : mergedArray) 
	        {
	            System.out.print(num + " ");
	        }
	    }
	    
	    public static int[] mergeArrays(int[] array1, int[] array2) {
	    	
	        int[] mergedArray = new int[array1.length + array2.length];
	        
	        int i = 0, j = 0, k = 0;
	        
	        while (i < array1.length && j < array2.length) 
	        {
	            if (array1[i] < array2[j])
	            {
	                mergedArray[k++] = array1[i++];
	            }
	            else 
	            {
	                mergedArray[k++] = array2[j++];
	            }
	        }
	        
	        while (i < array1.length) 
	        {
	            mergedArray[k++] = array1[i++];
	        }
	        
	        while (j < array2.length)
	        {
	            mergedArray[k++] = array2[j++];
	        }
	        
	        return mergedArray;

	}

}
