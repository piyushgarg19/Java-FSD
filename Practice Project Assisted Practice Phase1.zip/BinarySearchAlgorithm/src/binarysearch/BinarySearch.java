package binarysearch;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr = {11,22,33,44,55};
		int key = 44;
		int arrlength = arr.length;
		
		binarysearch(arr, 1, key, arrlength);
	}
	
	public static int binarysearch(int[] arr, int start, int key, int length)
	
	{
		int midValue = (start+length)/2;
		while(start<=length)
		{
			if(arr[midValue]<key)
			{
				start = midValue+1;
			}
			
			else if(arr[midValue]==key)
			{
				
				System.out.println("Element found at index" + midValue);
				break;
			}
			else
			{

				length=midValue-1;
			}
		
			midValue = (start+length)/2;
		}
		if(start>length)
		{
			System.out.println("Element is not found");
		}

		return midValue;
}
}

