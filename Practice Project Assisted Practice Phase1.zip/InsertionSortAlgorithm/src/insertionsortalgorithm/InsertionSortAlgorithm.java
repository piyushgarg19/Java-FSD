package insertionsortalgorithm;

public class InsertionSortAlgorithm {
	
	public static void sort(int[] array) {
		
        for (int i = 1; i < array.length; i++) 
        {
            int key = array[i];
            int j = i-1;
            while (j >= 0 && array[j] > key) 
            {
                array	[j + 1] = array[j];
                j--;
            }
            
            array[j + 1] = key;
        }
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int[] array = {10, 5, 2, 7, 3, 1, 9, 6, 4, 8};
		  
	        sort(array);
	        
	        for (int i = 0; i < array.length; i++)
	        {
	            System.out.println(array[i]);
	        }

	}

}
