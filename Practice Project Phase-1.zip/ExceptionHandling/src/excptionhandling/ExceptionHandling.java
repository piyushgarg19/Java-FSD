package excptionhandling;

import java.util.Scanner;
public class ExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
	        
	        System.out.print("Enter a dividend: ");
	        int dividend = scanner.nextInt();
	        
	        System.out.print("Enter a divisor: ");
	        int divisor = scanner.nextInt();
	        
	        try {
	            int quotient = divide(dividend, divisor);
	            System.out.println("Quotient: " + quotient);
	        } 
	         catch (ArithmeticException e) {
	            System.out.println("Error: " + e.getMessage());
	         }
	       
	        finally {
	            scanner.close();
	        }
	    }
	    
	    public static int divide(int dividend, int divisor) {
	        if (divisor == 0) {
	            throw new ArithmeticException("Division by zero is not allowed.");
	        }
	        
	        return dividend / divisor;

	}

}
