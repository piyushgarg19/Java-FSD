package customexceptions;

class MyException extends Exception {
    public MyException(String message) {
        super(message);
    }
}

public class CustomExceptions {
    public static void main(String[] args) {
        try {
        	
            divideNumbers(10, 0);
        } 
         catch (MyException e)
        {
            System.out.println("Custom Exception caught: " + e.getMessage());
        }
         finally
        {
            System.out.println("Finally block executed");
        }
    }
    
    public static void divideNumbers(int a, int b) throws MyException {
        try {
            if (b == 0) {
                throw new MyException("Divide by zero exception");
            }
            int result = a / b;
            System.out.println("Result: " + result);
        }
         finally 
         {
            System.out.println("Finally block in divideNumbers() executed");
        }
    }
}




