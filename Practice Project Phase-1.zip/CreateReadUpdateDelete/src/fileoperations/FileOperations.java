package fileoperations;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class FileOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Enter your choice:");
            System.out.println("1. Create a file");
            System.out.println("2. Read a file");
            System.out.println("3. Update a file");
            System.out.println("4. Delete a file");
            System.out.println("5. Exit");
            
            int choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    createFile(scanner);
                    break;
                case 2:
                    readFile(scanner);
                    break;
                case 3:
                    updateFile(scanner);
                    break;
                case 4:
                    deleteFile(scanner);
                    break;
                case 5:
                    System.out.println("Exiting program...");
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }
        }
    }
    
    private static void createFile(Scanner scanner) {
        System.out.println("Enter the file name:");
        String fileName = scanner.next();
        
        try 
        {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created successfully.");
            } 
             else 
             {
                System.out.println("File already exists.");
            }
        } 
         catch (IOException e) 
        {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
    
    private static void readFile(Scanner scanner) {
        System.out.println("Enter the file name:");
        String fileName = scanner.next();
        
        try 
        {
            String content = new String(Files.readAllBytes(Paths.get(fileName)));
            System.out.println("File content:\n" + content);
        } 
         catch (IOException e) 
        {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
    
    private static void updateFile(Scanner scanner) {
        System.out.println("Enter the file name:");
        String fileName = scanner.next();
        
        try 
        {
            System.out.println("Enter the new content:");
            scanner.nextLine(); // Consume newline character
            String content = scanner.nextLine();
            
            Files.write(Paths.get(fileName), content.getBytes());
            System.out.println("File updated successfully.");
        } 
         catch (IOException e)
        {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
    
    private static void deleteFile(Scanner scanner) {
        System.out.println("Enter the file name:");
        String fileName = scanner.next();
        
        try
        {
            Files.deleteIfExists(Paths.get(fileName));
            System.out.println("File deleted successfully.");
        }
         catch (IOException e)
        {
            System.out.println("An error occurred: " + e.getMessage());
        }

	}

}
