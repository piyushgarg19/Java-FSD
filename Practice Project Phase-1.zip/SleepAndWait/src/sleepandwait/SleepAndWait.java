package sleepandwait;

public class SleepAndWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread sleepThread = new SleepThread();
        Thread waitThread = new WaitThread();

        sleepThread.start();
        waitThread.start();
    }
}

class SleepThread extends Thread {
	
    @Override
    public void run()
    {
        System.out.println("SleepThread started.");

        try {
            // Sleep for 3 seconds
            Thread.sleep(3000);
        } 
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        System.out.println("SleepThread finished.");
    }
}

class WaitThread extends Thread {
	
    @Override
    public void run()
    {
        System.out.println("WaitThread started.");

        synchronized (this) 
        {
            try
            {
                // Wait for 3 seconds
                wait(3000);
            } 
             catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }

        System.out.println("WaitThread finished.");
        
    }

}
