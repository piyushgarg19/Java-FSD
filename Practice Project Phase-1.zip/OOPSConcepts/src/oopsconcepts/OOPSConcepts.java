package oopsconcepts;

interface Animal {
    void makeSound();
}

interface Mammal extends Animal {
    void run();
}

interface Bird extends Animal {
    void fly();
}

// Class Bat implements both Mammal and Bird interfaces

class Bat implements Mammal, Bird {
    public void makeSound() {
        System.out.println("Bat: Screech!");
    }

    public void run() {
        System.out.println("Bat: Flying faster!");
    }

    public void fly() {
        System.out.println("Bat: Taking off!");
    }
}


public class OOPSConcepts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		       Bat bat = new Bat();
		        bat.makeSound();
		        bat.run();
		        bat.fly();

	}

}
