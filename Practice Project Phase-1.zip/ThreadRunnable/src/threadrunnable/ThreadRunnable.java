package threadrunnable;

//Thread by extending Thread class
class MyThread extends Thread {
 public void run() 
 {
     System.out.println("Thread created by extending Thread class");
     }
 }

//Thread by implementing Runnable interface

class MyRunnable implements Runnable {
	public void run() 
	{
     System.out.println("Thread created by implementing Runnable interface");
     }
}

public class ThreadRunnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create thread by extending Thread class
		
        MyThread thread1 = new MyThread();
        thread1.start();

        // Create thread by implementing Runnable interface
        
        MyRunnable runnable = new MyRunnable();
        Thread thread2 = new Thread(runnable);
        thread2.start();

	}

}
