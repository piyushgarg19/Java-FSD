package trycatchexample;

public class TryCatchExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] numbers = { 1, 2, 3, 4, 5 };
	        int index = 3;
	        
	        try
	        {
	            int result = numbers[index];
	            System.out.println("The value at index " + index + " is: " + result);
	        } 
	          catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("Error: Index is out of bounds.");
	        }
	        
	        System.out.println("Program continues after the try-catch block.");

	}

}
