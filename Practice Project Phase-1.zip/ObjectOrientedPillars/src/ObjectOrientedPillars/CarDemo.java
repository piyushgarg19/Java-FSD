package ObjectOrientedPillars;

class Car {
	
    // Instance variables
	
    private String make;
    private String model;
    private int year;
    
 // Constructor
    
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    // Getter methods
    
    public String getMake()
    {
        return make;
    }
    
    public String getModel() 
    {
        return model;
    }
    
    public int getYear()
    {
        return year;
    }
    
    // Method to display car information
    
    public void displayInfo() {
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }
}


public class CarDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Car car1 = new Car("Toyota", "Camry", 2020);
        Car car2 = new Car("Honda", "Civic", 2019);
        
        // Accessing object properties and methods
        System.out.println("Car 1:");
        System.out.println("Make: " + car1.getMake());
        System.out.println("Model: " + car1.getModel());
        System.out.println("Year: " + car1.getYear());
        
        System.out.println();
        
        System.out.println("Car 2:");
        System.out.println("Make: " + car2.getMake());
        System.out.println("Model: " + car2.getModel());
        System.out.println("Year: " + car2.getYear());
        
        System.out.println();
        
        // Calling object method to display car information
        
        System.out.println("Car 1 Information:");
        car1.displayInfo();
        
        System.out.println();
        
        System.out.println("Car 2 Information:");
        car2.displayInfo();


	}

}
