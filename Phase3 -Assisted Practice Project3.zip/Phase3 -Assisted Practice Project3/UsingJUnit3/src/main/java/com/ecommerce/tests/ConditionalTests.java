package com.ecommerce.tests;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;



@DisplayName("JUnit5 Conditional Tests Example")

public class ConditionalTests {
	@Test
    @EnabledOnOs({OS.WINDOWS})
    public void runOnWindows() {
            System.out.println("This runs on Windows");
    }

    @Test
    @EnabledOnOs({OS.LINUX})
    public void runOnLinux() {
            System.out.println("This runs on Linux");
    }

    
}


