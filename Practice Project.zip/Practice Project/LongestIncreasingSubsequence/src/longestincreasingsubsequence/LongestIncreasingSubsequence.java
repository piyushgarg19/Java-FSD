package longestincreasingsubsequence;

import java.util.ArrayList;
import java.util.List;

public class LongestIncreasingSubsequence {
	
	public static List<Integer> findLongestIncreasingSubsequence(List<Integer> numbers) {
		
        int n = numbers.size();
        int[] lengths = new int[n];
        int[] previousIndices = new int[n];

        for (int i = 0; i < n; i++)
        {
            lengths[i] = 1;
            previousIndices[i] = -1;

            for (int j = 0; j < i; j++)
            {
                if (numbers.get(i) > numbers.get(j) && lengths[j] + 1 > lengths[i]) 
                {
                    lengths[i] = lengths[j] + 1;
                    previousIndices[i] = j;
                }
            }
        }

        int maxLengthIndex = 0;
        int maxLength = 0;
        for (int i = 0; i < n; i++)
        {
            if (lengths[i] > maxLength) 
            {
                maxLength = lengths[i];
                maxLengthIndex = i;
            }
        }

        List<Integer> longestSubsequence = new ArrayList<>();
        while (maxLengthIndex != -1)
        {
            longestSubsequence.add(numbers.get(maxLengthIndex));
            maxLengthIndex = previousIndices[maxLengthIndex];
        }

        return longestSubsequence;
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 List<Integer> numbers = new ArrayList<>();
		 
	        numbers.add(15);
	        numbers.add(25);
	        numbers.add(2);
	        numbers.add(1);
	        numbers.add(30);

	        List<Integer> longestSubsequence = findLongestIncreasingSubsequence(numbers);
	        System.out.println("Longest increasing subsequence: " + longestSubsequence);

	}

}
