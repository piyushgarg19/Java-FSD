package arithmeticcalculator;

import java.util.Scanner;
public class ArithmeticCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		double num1, num2;
		String operator;
		
		System.out.print("Enter the first number");
		num1= scanner.nextDouble();	
		
		System.out.print("Enter the second number");
		num2= scanner.nextDouble();
		
		System.out.println("Enter an operator");
		System.out.println("+");
		System.out.println("-");
		System.out.println("*");
		System.out.println("/");
		
		operator= scanner.next();
		
		double result;
		
		switch(operator) {
		
		case "+":
		    result= num1+num2;
	     	System.out.println("Result" +result);
		    break;
		
		case "-":
		     result= num1-num2;
		     System.out.println("Result" +result);
		     break;
		
		case "*":
			result=num1*num2;
			System.out.println("Result" +result);
			
		case "/":
			if (num2 !=0) 
			{
				result=num1/num2;
				System.out.println("Result" +result);
			}
			
			else
			{
				System.out.println("Print Operator");
			}
			
			break;
			default:
				System.out.println("valid operator");
				break;
			
		
		}
		

	}

}
