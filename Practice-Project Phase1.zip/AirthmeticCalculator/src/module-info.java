/**
 * 
 */
/**
 * 
 */
module AirthmeticCalculator {
}