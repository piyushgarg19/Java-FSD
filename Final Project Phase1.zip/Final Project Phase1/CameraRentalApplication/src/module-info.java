/**
 * 
 */
/**
 * 
 */
module CameraRentalAppkication {
}