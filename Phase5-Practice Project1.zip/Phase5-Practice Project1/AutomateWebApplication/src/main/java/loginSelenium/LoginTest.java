package loginSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		  WebDriver driver = new ChromeDriver();
		  
			  
			driver.manage().window().maximize();
			driver.get("https://leetcode.com/accounts/login/");
			
			WebElement username = driver.findElement(By.id("id_login"));
			WebElement password = driver.findElement(By.id("id_password"));
			//Entering credentials
			System.out.println("Login Automation Started....");
			username.clear();//clear id_login field if any filled
			
			username.sendKeys("pg67824@gmail.com");//use your email id
			System.out.println("Username is Entered.");
			
			password.clear();//clear id_password field if any filled
			password.sendKeys("Nannu@19");// use your password
			System.out.println("Password is Entered");
			
			System.out.println("Clicked On SignIn Button");
			


	}

}
