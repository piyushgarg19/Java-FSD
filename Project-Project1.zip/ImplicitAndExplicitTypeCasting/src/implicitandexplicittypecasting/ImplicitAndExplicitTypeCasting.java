package implicitandexplicittypecasting;

public class ImplicitAndExplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Implicit Type Casting
		
		int intValue = 50;
		long longValue = intValue;
		float floatValue = longValue; 
		double doubleValue = floatValue;
		
		System.out.println("Implicit Type Casting");
		System.out.println("int value" +intValue);
		System.out.println("long value" +longValue);
		System.out.println("float value" +floatValue);
		System.out.println("double value" +doubleValue);
		
		// Explicit Type Casting
		
		double doubleNum = 101.33;
		float floatNum = (float) doubleNum;
		long longNum = (long) floatNum;
		int intNum = (int) longNum;
		
		System.out.println("\n Explicit Type Casting");
		System.out.println("double value" +doubleNum);
		System.out.println("float value" +floatNum);
		System.out.println("long value" +longNum);
		System.out.println("int value" +intNum);
			
	}

}
