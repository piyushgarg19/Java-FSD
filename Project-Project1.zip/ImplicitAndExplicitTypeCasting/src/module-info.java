/**
 * 
 */
/**
 * 
 */
module ImplicitAndExplicitTypeCasting {
}